package Zadanie2;


//LabSis_Saduakas_Madi_01
class ExamChecker extends Thread {
    private final int sheetsToCheck;

    public ExamChecker(int sheetsToCheck, String assistantName) {
        super(assistantName);
        this.sheetsToCheck = sheetsToCheck;
    }

    @Override
    public void run() {
        for (int i = 1; i <= sheetsToCheck; i++) {
            System.out.println(getName() + " cheking mistake " + i + "/" + sheetsToCheck);
            try {
                Thread.sleep(300); // пауза 300 миллисекунд
            } catch (InterruptedException e) {
                System.err.println(getName() + " ERROR!");
            }
        }
        System.out.println(getName() + " Completed!!!!.");
    }

    public static void main(String[] args) {
        ExamChecker checker1 = new ExamChecker(5, "Assistant-1");
        ExamChecker checker2 = new ExamChecker(3, "Assistant-2");

        checker1.start();
        checker2.start();
    }
}
