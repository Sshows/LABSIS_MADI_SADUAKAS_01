package Zadanie2;

//LabSis_Saduakas_Madi_01
public class ExamSimulation {
    public static void main(String[] args) {
        int totalSheets = 500;
        int sheetsPerAssistant = 50;

        System.out.println("Start of cheking\n");

        // Создание потоков для каждого ассистента
        for (int i = 1; i <= totalSheets / sheetsPerAssistant; i++) {
            String assistantName = "Assistant-" + i;
            ExamChecker assistant = new ExamChecker(sheetsPerAssistant, assistantName);
            assistant.start();
        }
    }
}
