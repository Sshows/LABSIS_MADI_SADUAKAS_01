package Zadanie1;


import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ShapeClient {
    public static void main(String[] args) {
        final String HOST = "localhost";
        final int PORT = 1234;

        try (
                Socket socket = new Socket(HOST, PORT);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Scanner scanner = new Scanner(System.in)
        ) {
            while (true) {
                System.out.println("Enter shape Circle/Rectangle or 'Q' to quit and exit:");
                String input = scanner.nextLine().trim();

                if (input.equalsIgnoreCase("Q")) {
                    outputStream.writeObject(null); // Отправка сигнала завершения серверу
                    break;
                }

                GeometricShape shape = null;

                if (input.equalsIgnoreCase("Circle")) {
                    System.out.print("Enter radius: ");
                    double radius = scanner.nextDouble();
                    scanner.nextLine(); // Очистка буфера после чтения числа
                    shape = new Circle(radius);
                } else if (input.equalsIgnoreCase("Rectangle")) {
                    System.out.print("Enter width and height (separated by space): ");
                    double width = scanner.nextDouble();
                    double height = scanner.nextDouble();
                    scanner.nextLine(); // Очистка буфера после чтения чисел
                    shape = new Rectangle(width, height);
                } else {
                    System.out.println("Invalid shape type. Try again.");
                    continue;
                }

                outputStream.writeObject(shape); // Отправка объекта фигуры на сервер

                // Чтение ответа от сервера
                String response = (String) inputStream.readObject();
                System.out.println("Server response: " + response);
            }

            System.out.println("Client terminated.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
