package Zadanie1;

//LabSis_Saduakas_Madi_01
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class ShapeServer {
    public static void main(String[] args) {
        final int PORT = 1234;

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is running on port " + PORT + "...");

            try (
                    Socket clientSocket = serverSocket.accept();
                    ObjectInputStream inputStream = new ObjectInputStream(clientSocket.getInputStream());
                    ObjectOutputStream outputStream = new ObjectOutputStream(clientSocket.getOutputStream())
            ) {
                System.out.println("Client connected.");

                while (true) {
                    GeometricShape shape = (GeometricShape) inputStream.readObject();

                    if (shape == null) {
                        break; // Если клиент отправил null, завершаем соединение
                    }

                    System.out.println("Received a " + shape.getShapeType());
                    String response = "Area of " + shape.getShapeType() + ": " + shape.calculateArea();
                    outputStream.writeObject(response); // Отправка ответа клиенту
                }

                System.out.println("Connection closed by client.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
